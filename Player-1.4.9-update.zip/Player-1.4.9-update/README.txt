Player 1.4.9 update package
==========================

Your songs, setlists and settings aren't touched. The version you have now is kept, so you can go back to it.

Player 1.4.0 or later
---------------------
1. In Player, open Settings ▸ About ▸ Update… (or Player ▸ Check for Updates…).
2. Under From a Zip, click Install from Zip… and choose this zip (no need to unzip it).
3. Click Install and Restart.
To go back: the same window ▸ Previous Version ▸ Go Back.

Player 1.3.0 or earlier, on a Mac (no Install from Zip yet)
-----------------------------------------------------------
1. Unzip this file in your Downloads folder (double-click it).
2. Open Terminal (Applications ▸ Utilities ▸ Terminal).
3. Paste this line and press Return:

     bash ~/Downloads/Player-1.4.9-update/install-on-mac.sh

   If macOS asks whether Terminal may access Downloads or change apps, click Allow.
4. The script quits Player, keeps the version you have for Go Back, puts 1.4.9 in,
   signs the app again (as the release build does) and opens it.
To go back afterwards: Settings ▸ About ▸ Update… ▸ Go Back, or run the command the script prints at the end.

Windows
-------
Player 1.4.0 or later: Install from Zip…, as above. For Player 1.3.0 on Windows, install
the whole app once (Player-Setup-<version>.exe) from a release; after that, packages work.
